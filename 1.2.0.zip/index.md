---
layout: page
home-title: Homepage of Wang Tongyu
description: A website of Wang Tongyu. HE IS TRY TO THINK DIFFERENT EVERYDAY
header-img: assets/img/banner.png
---

# About me

&emsp;&emsp;I am a Master student from Japan Advanced Institute of Science and Technology (JAIST). I'm now working in [ReaLearn](https://sites.google.com/view/racharak-lab) (the Reasoning & Learning for Trustworthy AI laboratory) at JAIST.

# Publications

1. Application of Edge Computing in 5g Communications [[DOI 10.1088/1757-899X/740/1/012130]](https://iopscience.iop.org/article/10.1088/1757-899X/740/1/012130/pdf)

# Contact

Email: Twang[aaaaatttttt]jaist.ac.jp (Please replace [aaaaatttttt] with @.)

- - - 
## Chinese is below(此处开始为中文)

# 关于我

&emsp;&emsp;我是一名来自日本北陆先端科学技术大学院大学的硕士研究生，现在隶属于该学校ReaLearn(可信赖人工智能的推理与学习）研究室。

# 论文发表

1. Application of Edge Computing in 5g Communications [[DOI 10.1088/1757-899X/740/1/012130]](https://iopscience.iop.org/article/10.1088/1757-899X/740/1/012130/pdf)


# 联系我

邮箱：Twang[aaaaatttttt]jaist.ac.jp (请使用@替换[aaaaatttttt])
